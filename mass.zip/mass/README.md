# Massseen
Massseen is Instagram automation tool to view thousands of stories with in minutes without getting action block. 

## Features
- View Stories
  
## Uses 
- Increasing profile visits and followers

## What's Changed?
- Disabled features other than view stories
- Changed target
- Changed delay
- Changed timezone
- Changed from static to dynamic random delay method
- Added auto relaunch feature when the program stopped
   
## Installation

Requires at least PHP version 5.6 to run.

Turn off Two-factor authentication (2FA).

```
$ sudo apt-get install php git mc
$ git clone https://github.com/gvoze32/massseen
$ cd massseen
$ php login.php
$ bash start.sh
```

## Credits
Author credits : nthanfp

Modified by mohsanjid ([Repository](https://github.com/sanjidtk/masslooker))

Remodified by gvoze32
